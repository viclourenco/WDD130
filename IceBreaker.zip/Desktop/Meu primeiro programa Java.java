public class MeuProgramaJava{
    public static void main(String[] args) //método principal que tem retorno estático e vazio 
{
System.out.println("Meu primeiro programa Java");

}


}